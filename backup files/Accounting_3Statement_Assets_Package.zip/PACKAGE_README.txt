Package contents (what each file is for)

EXCEL MODELS
1) Financial_Model_TEMPLATE_ZERO_USD_thousands_GAAP.xlsx
   - Processing template used by the backend.
   - All manual input cells are 0 to avoid “default numbers” leaking into outputs.
   - Unit: USD thousands (backend should convert USD dollars -> thousands when needed).

2) Financial_Model_SAMPLE_DEMO_USD_thousands_GAAP.xlsx
   - Sample demo model with realistic non-zero numbers.
   - Used ONLY for the “Download Sample Model (Demo)” button so users can see it works.
   - NOT used for processing.

SAMPLE DATA (PRIMARY)
3) sample_tb.csv / sample_tb.xlsx
   - Trial Balance sample (no TransactionID column).
   - Headers: TxnDate, AccountNumber, AccountName, Debit, Credit, Currency.
4) sample_gl_with_txnid.csv / .xlsx
   - GL Activity sample WITH optional TransactionID column.
5) sample_gl_no_txnid.csv / .xlsx
   - GL Activity sample WITHOUT TransactionID (to test optional behavior).

BACKUP / STRESS-TEST GL DATASETS (for “Load Random Test Dataset” button)
- backup_gl_2020_2021_with_txnid.(csv|xlsx)
- backup_gl_2021_2022_with_txnid.(csv|xlsx)
- backup_gl_2022_2023_no_txnid.(csv|xlsx)
- backup_gl_2023_2024_with_txnid.(csv|xlsx)
- backup_gl_2024_2025_no_txnid.(csv|xlsx)

Column matching rule:
- Match by header name (case-insensitive), NOT by column order.
- Extra columns ignored.
- Missing required columns must trigger warnings (and block only the parts that cannot run).
